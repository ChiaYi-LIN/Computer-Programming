#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>

using namespace std;

int reverseSortNumber(int inputNumber);
int sortNumber(int inputNumber);
int output(int reverseSortNumber, int sortNumber);
