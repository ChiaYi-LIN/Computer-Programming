#include <iostream>
#include <cstdio>

using namespace EE1004;

int main()
{
    cout << "Seafood are awesome!";
    cout << '\b' << '\b' << '\b' << '\b' << '\b' << '\b' << '\b' << '\b' << '\b' << '\b' << '\b' << '\b';//Insert a line here. Do not modify other part.
    cout << "is awesome!";

    cout << endl;
    printf("%c%c%c %c%c%c%c\n",78,84,85,78,79,46,49);//Please printf "NTU NO.1" used ASCII code
}

