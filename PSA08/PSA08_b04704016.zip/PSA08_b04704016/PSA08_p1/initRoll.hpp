//
//  initRoll.hpp
//  PSA08_p1
//


#ifndef initRoll_hpp
#define initRoll_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

int initialRoll(int firstPoint);


#endif /* initRoll_hpp */
