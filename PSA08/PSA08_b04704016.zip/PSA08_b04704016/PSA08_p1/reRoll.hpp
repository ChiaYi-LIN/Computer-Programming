//
//  reRoll.hpp
//  PSA08_p1
//
//  Created by 陳泓弦 on 2017/11/26.
//  Copyright © 2017年 陳泓弦. All rights reserved.
//

#ifndef reRoll_hpp
#define reRoll_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

int reRoll(int firstPoint, int point);



#endif /* reRoll_hpp */
